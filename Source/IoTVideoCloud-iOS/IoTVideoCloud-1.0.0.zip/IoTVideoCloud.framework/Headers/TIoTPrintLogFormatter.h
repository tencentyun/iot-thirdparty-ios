//
//  TIoTPrintLogFormatter.h
//  LinkApp
//

/**
 自定义日志格式
 */

#import <Foundation/Foundation.h>
#import "DDLog.h"

NS_ASSUME_NONNULL_BEGIN

@interface TIoTPrintLogFormatter : NSObject<DDLogFormatter>

@end

NS_ASSUME_NONNULL_END
