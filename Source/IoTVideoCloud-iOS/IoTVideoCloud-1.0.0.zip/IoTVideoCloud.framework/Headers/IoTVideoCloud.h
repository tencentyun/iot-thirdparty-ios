//
//  TIoTCoreXP2PBridge.h
//  TIoTLinkKitDemo
//
//

#import <Foundation/Foundation.h>
#import <TXLiteAVSDK_TRTC/TRTCCloud.h>

NS_ASSUME_NONNULL_BEGIN

extern NSNotificationName const TIoTCoreXP2PBridgeNotificationDisconnect;
extern NSNotificationName const TIoTCoreXP2PBridgeNotificationReady;
extern NSNotificationName const TIoTCoreXP2PBridgeNotificationDeviceMsg;
extern NSNotificationName const TIoTCoreXP2PBridgeNotificationStreamEnd;

typedef enum {
    RTCTypeDisconnect       = 3000,     //对端退出
    RTCTypeDetectReady      = 3001,     //对端已进房
    RTCTypeDetectError      = 3002      //进房链路初始化失败
} IoTVideoEventType;

@protocol IoTVideoCloudDelegate <NSObject>
@optional
/*
 * 进房成功回调
 *
 * 使用方式:实现IoTVideoCloudDelegate
 */
- (void)joinRoomSuccess;


/*
 * 进房失败回调
 *
 * errmsg:错误信息
 */
- (void)joinRoomFailed:(NSString *)errmsg;

//远端设备进房啦
- (void)onRemoteUserEnterRoom:(NSString *)deviceId;

//0表示设备主动退出房间，1表示用户超时退出，2表示被踢出房间，3表示主播因切换到观众退出房间。
- (void)onRemoteUserLeaveRoom:(NSString *)deviceId reason:(NSInteger)reason;

//远端设备推流啦
- (void)onUserVideoAvailable:(id)object device:(NSString *)deviceId available:(BOOL)available;

//远端设备发消息啦
- (void)onRecvCustomCmdMsgUserId:(NSString *)deviceId cmdID:(NSInteger)cmdID seq:(UInt32)seq message:(NSData *)message;

//远端设备第一帧到达啦
- (void)onFirstVideoFrame:(NSString *)deviceId streamType:(TRTCVideoStreamType)streamType width:(int)width height:(int)height;

@end





@interface IoTVideoParams : NSObject
@property (nonatomic, strong)NSString *openId; //用户系统userid，如微信授权的openid
@property (nonatomic, strong)NSString *productId;
@property (nonatomic, strong)NSString *deviceName;
@property (nonatomic, strong)NSString *avType; //audio: 单音频  - video: 音视频
@property (nonatomic, strong)NSString *sessionId;
@property (nonatomic, strong)NSArray *channelList;
@end





@interface IoTVideoCloud : NSObject
@property (nonatomic, weak)id<IoTVideoCloudDelegate> delegate;

/*
 * 开关是否将数据帧写入 Document 目录的 video.data 文件 （后缀可导出后改动）
 */
@property (nonatomic, assign)BOOL writeFile;

/*
 * 是否打印 SDK Log，默认关
 */
@property (nonatomic, assign)BOOL logEnable;

+ (instancetype)sharedInstance ;

// 不建议使用下面两个start接口，避免泄漏您的secretid和secretkey，会造成您的账户泄漏，demo仅用此接口做演示使用
- (void)startAppWith:(IoTVideoParams *)params;

/*
 * 退出 SDK 服务
 */
- (void)stopAppService:(NSString *)dev_name;

/*
 * 开始推流接口
 *
 */
- (void)startLocalStream:(NSString *)dev_name;

/*
 *停止本地流
 */
- (void)stopLocalStream;

/*
 * 开始拉流接口
 * ⚠️ 当使用p2p模式时候，使用播放器播放时，需先等待 SDK 初始化完成，ready事件之后，即可获取到 http-url 开始拉流
 * ⚠️ 当使用rtc模式时候，使用内部播放只需传入remoteView、LocalView展示UI
 */
- (NSString *)startRemoteStream:(NSString *)dev_name;

/*
 * 与设备信令交互接口
 * 1.设备端回复 app 的消息没有限制
 * 2.app 发送给设备的信令，要求不带&符号，信令长度不超过3000个字节
 *
 * 事例 cmd 参数（action=inner_define&cmd=get_nvr_list）
 */
- (void)sendCustomCmdMsg:(NSString *)dev_name cmd:(NSString *)cmd timeout:(uint64_t)timeout completion:(void (^ __nullable)(NSString * jsonList))completion;


/*
 * 打开本地预览，可提前看到本端画面
 */
- (void)openCamera:(BOOL)frontCamera view:(UIView *)previewView;

//刷新本地预览视图
- (void)refreshLocalView:(UIView *)localView;
//切换前后摄像头
- (void)changeCameraPositon;
//设置听筒还是扬声器模式，yes=扬声器，no=听筒
- (void)setAudioRoute:(BOOL)isHandsFree ;
//静音或回复音频
- (void)muteLocalAudio:(BOOL)mute;
//静音或回复音频
- (void)muteLocalVideo:(BOOL)mute;

// 新增：获取正确的TRTC实例
- (TRTCCloud *)getTRTCInstanceForDevice:(id)object device:(NSString *)deviceId;

/*
 * 调试接口，录制通过播放器拉取的数据流并行保存到 Document 目录的 video.data 文件
 * 需提前打开 writeFile 开关
 */
+ (void)recordstream:(NSString *)dev_name;

/*
 * 获取当前发送链路的连接模式：0 无效；62 直连；63 转发
 */
+ (int)getStreamLinkMode:(NSString *)dev_name;


@end

NS_ASSUME_NONNULL_END
