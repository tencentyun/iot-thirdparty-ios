void *getSDKStartAddress(void);
void *getSDKEndAddress(void);

long getExecuteImageSlide(void);
